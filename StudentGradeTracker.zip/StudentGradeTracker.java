import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentGradeTracker {

    // Function to calculate the average grade
    public static double calculateAverage(ArrayList<Integer> grades) {
        int total = 0;
        for (int grade : grades) {
            total += grade;
        }
        return (double) total / grades.size();
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> studentNames = new ArrayList<>();
        ArrayList<Integer> studentGrades = new ArrayList<>();

        System.out.println("=========== Student Grade Tracker ===========");
        System.out.println("Enter student names and their grades.\nType 'done' when you finish.\n");

        // Input loop for student data
        while (true) {
            System.out.print("Enter student name (or type 'done' to finish): ");
            String name = scanner.nextLine();
            if (name.equalsIgnoreCase("done")) {
                break;
            }

            System.out.print("Enter grade for " + name + ": ");
            int grade = scanner.nextInt();
            scanner.nextLine(); // Clear the buffer

            studentNames.add(name);
            studentGrades.add(grade);
        }

        // Displaying the results if there are students
        if (studentGrades.size() > 0) {
            System.out.println("\n=========== Grade Summary ===========");

            // Display each student's name and grade
            System.out.println("Student Grades:");
            for (int i = 0; i < studentNames.size(); i++) {
                System.out.println(studentNames.get(i) + ": " + studentGrades.get(i));
            }

            // Calculating average, highest, and lowest grades
            double averageGrade = calculateAverage(studentGrades);
            int highestGrade = Collections.max(studentGrades);
            int lowestGrade = Collections.min(studentGrades);

            // Displaying statistics
            System.out.println("\nStatistics:");
            System.out.printf("Average Grade: %.2f\n", averageGrade);
            System.out.println("Highest Grade: " + highestGrade);
            System.out.println("Lowest Grade: " + lowestGrade);
        } else {
            System.out.println("No student data entered.");
        }

        System.out.println("===========================================");
        scanner.close();
    }
}
